﻿namespace ResizeImages
{
    partial class Prop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gBImgShowed = new System.Windows.Forms.GroupBox();
            this.ImgShVertical = new System.Windows.Forms.GroupBox();
            this.nmShVerHeigth = new System.Windows.Forms.NumericUpDown();
            this.lblShVerHeigth = new System.Windows.Forms.Label();
            this.nmShVerWidth = new System.Windows.Forms.NumericUpDown();
            this.lblShVerWidth = new System.Windows.Forms.Label();
            this.ImgShHorizontal = new System.Windows.Forms.GroupBox();
            this.nmShHorWidth = new System.Windows.Forms.NumericUpDown();
            this.nmShHorHeigth = new System.Windows.Forms.NumericUpDown();
            this.lblShHorWidth = new System.Windows.Forms.Label();
            this.lblShHeight = new System.Windows.Forms.Label();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.gbImgNewDim = new System.Windows.Forms.GroupBox();
            this.gBNewVertical = new System.Windows.Forms.GroupBox();
            this.nmNewVerHeigth = new System.Windows.Forms.NumericUpDown();
            this.nmNewVerWidth = new System.Windows.Forms.NumericUpDown();
            this.lblNewVerHeigth = new System.Windows.Forms.Label();
            this.lblNewVerWidth = new System.Windows.Forms.Label();
            this.gbNewHorizontal = new System.Windows.Forms.GroupBox();
            this.nmNewHorHeigth = new System.Windows.Forms.NumericUpDown();
            this.nmNewHorWidth = new System.Windows.Forms.NumericUpDown();
            this.lblNewHorHeigth = new System.Windows.Forms.Label();
            this.lblNewHorWidth = new System.Windows.Forms.Label();
            this.gBMarcaAgua = new System.Windows.Forms.GroupBox();
            this.txtBPropMarcaAgua = new System.Windows.Forms.TextBox();
            this.lblTextoMarcaAgua = new System.Windows.Forms.Label();
            this.gBImgTmbDim = new System.Windows.Forms.GroupBox();
            this.gBTmbVertical = new System.Windows.Forms.GroupBox();
            this.nmTmbVerHeigth = new System.Windows.Forms.NumericUpDown();
            this.nmTmbVerWidth = new System.Windows.Forms.NumericUpDown();
            this.lblTmbVerWidth = new System.Windows.Forms.Label();
            this.lblTmbVerHeigth = new System.Windows.Forms.Label();
            this.gBTmbHorizontal = new System.Windows.Forms.GroupBox();
            this.nmTmbHorHeigth = new System.Windows.Forms.NumericUpDown();
            this.nmTmbHorWidth = new System.Windows.Forms.NumericUpDown();
            this.lblTmbHorHeigth = new System.Windows.Forms.Label();
            this.lblTmbHorWidth = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.gBImgShowed.SuspendLayout();
            this.ImgShVertical.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmShVerHeigth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmShVerWidth)).BeginInit();
            this.ImgShHorizontal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmShHorWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmShHorHeigth)).BeginInit();
            this.gbImgNewDim.SuspendLayout();
            this.gBNewVertical.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmNewVerHeigth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmNewVerWidth)).BeginInit();
            this.gbNewHorizontal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmNewHorHeigth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmNewHorWidth)).BeginInit();
            this.gBMarcaAgua.SuspendLayout();
            this.gBImgTmbDim.SuspendLayout();
            this.gBTmbVertical.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmTmbVerHeigth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmTmbVerWidth)).BeginInit();
            this.gBTmbHorizontal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmTmbHorHeigth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmTmbHorWidth)).BeginInit();
            this.SuspendLayout();
            // 
            // gBImgShowed
            // 
            this.gBImgShowed.Controls.Add(this.ImgShVertical);
            this.gBImgShowed.Controls.Add(this.ImgShHorizontal);
            this.gBImgShowed.Location = new System.Drawing.Point(13, 13);
            this.gBImgShowed.Name = "gBImgShowed";
            this.gBImgShowed.Size = new System.Drawing.Size(239, 269);
            this.gBImgShowed.TabIndex = 0;
            this.gBImgShowed.TabStop = false;
            this.gBImgShowed.Text = "Imagen Mostrada";
            // 
            // ImgShVertical
            // 
            this.ImgShVertical.Controls.Add(this.nmShVerHeigth);
            this.ImgShVertical.Controls.Add(this.lblShVerHeigth);
            this.ImgShVertical.Controls.Add(this.nmShVerWidth);
            this.ImgShVertical.Controls.Add(this.lblShVerWidth);
            this.ImgShVertical.Location = new System.Drawing.Point(18, 147);
            this.ImgShVertical.Name = "ImgShVertical";
            this.ImgShVertical.Size = new System.Drawing.Size(200, 100);
            this.ImgShVertical.TabIndex = 6;
            this.ImgShVertical.TabStop = false;
            this.ImgShVertical.Text = "Vertical";
            // 
            // nmShVerHeigth
            // 
            this.nmShVerHeigth.Location = new System.Drawing.Point(88, 64);
            this.nmShVerHeigth.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nmShVerHeigth.Name = "nmShVerHeigth";
            this.nmShVerHeigth.Size = new System.Drawing.Size(94, 22);
            this.nmShVerHeigth.TabIndex = 3;
            // 
            // lblShVerHeigth
            // 
            this.lblShVerHeigth.AutoSize = true;
            this.lblShVerHeigth.Location = new System.Drawing.Point(29, 64);
            this.lblShVerHeigth.Name = "lblShVerHeigth";
            this.lblShVerHeigth.Size = new System.Drawing.Size(40, 17);
            this.lblShVerHeigth.TabIndex = 2;
            this.lblShVerHeigth.Text = "Alto: ";
            // 
            // nmShVerWidth
            // 
            this.nmShVerWidth.Location = new System.Drawing.Point(88, 33);
            this.nmShVerWidth.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.nmShVerWidth.Name = "nmShVerWidth";
            this.nmShVerWidth.Size = new System.Drawing.Size(94, 22);
            this.nmShVerWidth.TabIndex = 1;
            // 
            // lblShVerWidth
            // 
            this.lblShVerWidth.AutoSize = true;
            this.lblShVerWidth.Location = new System.Drawing.Point(16, 33);
            this.lblShVerWidth.Name = "lblShVerWidth";
            this.lblShVerWidth.Size = new System.Drawing.Size(56, 17);
            this.lblShVerWidth.TabIndex = 0;
            this.lblShVerWidth.Text = "Ancho: ";
            // 
            // ImgShHorizontal
            // 
            this.ImgShHorizontal.Controls.Add(this.nmShHorWidth);
            this.ImgShHorizontal.Controls.Add(this.nmShHorHeigth);
            this.ImgShHorizontal.Controls.Add(this.lblShHorWidth);
            this.ImgShHorizontal.Controls.Add(this.lblShHeight);
            this.ImgShHorizontal.Location = new System.Drawing.Point(18, 31);
            this.ImgShHorizontal.Name = "ImgShHorizontal";
            this.ImgShHorizontal.Size = new System.Drawing.Size(200, 100);
            this.ImgShHorizontal.TabIndex = 5;
            this.ImgShHorizontal.TabStop = false;
            this.ImgShHorizontal.Text = "Horizontal";
            // 
            // nmShHorWidth
            // 
            this.nmShHorWidth.Location = new System.Drawing.Point(88, 21);
            this.nmShHorWidth.Maximum = new decimal(new int[] {
            350,
            0,
            0,
            0});
            this.nmShHorWidth.Name = "nmShHorWidth";
            this.nmShHorWidth.Size = new System.Drawing.Size(94, 22);
            this.nmShHorWidth.TabIndex = 3;
            // 
            // nmShHorHeigth
            // 
            this.nmShHorHeigth.Location = new System.Drawing.Point(88, 50);
            this.nmShHorHeigth.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.nmShHorHeigth.Name = "nmShHorHeigth";
            this.nmShHorHeigth.Size = new System.Drawing.Size(94, 22);
            this.nmShHorHeigth.TabIndex = 4;
            // 
            // lblShHorWidth
            // 
            this.lblShHorWidth.AutoSize = true;
            this.lblShHorWidth.Location = new System.Drawing.Point(13, 21);
            this.lblShHorWidth.Name = "lblShHorWidth";
            this.lblShHorWidth.Size = new System.Drawing.Size(56, 17);
            this.lblShHorWidth.TabIndex = 1;
            this.lblShHorWidth.Text = "Ancho: ";
            // 
            // lblShHeight
            // 
            this.lblShHeight.AutoSize = true;
            this.lblShHeight.Location = new System.Drawing.Point(29, 50);
            this.lblShHeight.Name = "lblShHeight";
            this.lblShHeight.Size = new System.Drawing.Size(40, 17);
            this.lblShHeight.TabIndex = 2;
            this.lblShHeight.Text = "Alto: ";
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(608, 420);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(176, 46);
            this.btnGuardar.TabIndex = 1;
            this.btnGuardar.Text = "Guardar Nuevos Valores";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // gbImgNewDim
            // 
            this.gbImgNewDim.Controls.Add(this.gBNewVertical);
            this.gbImgNewDim.Controls.Add(this.gbNewHorizontal);
            this.gbImgNewDim.Location = new System.Drawing.Point(280, 13);
            this.gbImgNewDim.Name = "gbImgNewDim";
            this.gbImgNewDim.Size = new System.Drawing.Size(239, 269);
            this.gbImgNewDim.TabIndex = 2;
            this.gbImgNewDim.TabStop = false;
            this.gbImgNewDim.Text = "Nueva Imagen";
            // 
            // gBNewVertical
            // 
            this.gBNewVertical.Controls.Add(this.nmNewVerHeigth);
            this.gBNewVertical.Controls.Add(this.nmNewVerWidth);
            this.gBNewVertical.Controls.Add(this.lblNewVerHeigth);
            this.gBNewVertical.Controls.Add(this.lblNewVerWidth);
            this.gBNewVertical.Location = new System.Drawing.Point(25, 147);
            this.gBNewVertical.Name = "gBNewVertical";
            this.gBNewVertical.Size = new System.Drawing.Size(192, 100);
            this.gBNewVertical.TabIndex = 1;
            this.gBNewVertical.TabStop = false;
            this.gBNewVertical.Text = "Vertical";
            // 
            // nmNewVerHeigth
            // 
            this.nmNewVerHeigth.Location = new System.Drawing.Point(80, 63);
            this.nmNewVerHeigth.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmNewVerHeigth.Name = "nmNewVerHeigth";
            this.nmNewVerHeigth.Size = new System.Drawing.Size(95, 22);
            this.nmNewVerHeigth.TabIndex = 3;
            // 
            // nmNewVerWidth
            // 
            this.nmNewVerWidth.Location = new System.Drawing.Point(81, 32);
            this.nmNewVerWidth.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmNewVerWidth.Name = "nmNewVerWidth";
            this.nmNewVerWidth.Size = new System.Drawing.Size(94, 22);
            this.nmNewVerWidth.TabIndex = 2;
            // 
            // lblNewVerHeigth
            // 
            this.lblNewVerHeigth.AutoSize = true;
            this.lblNewVerHeigth.Location = new System.Drawing.Point(33, 64);
            this.lblNewVerHeigth.Name = "lblNewVerHeigth";
            this.lblNewVerHeigth.Size = new System.Drawing.Size(40, 17);
            this.lblNewVerHeigth.TabIndex = 1;
            this.lblNewVerHeigth.Text = "Alto: ";
            // 
            // lblNewVerWidth
            // 
            this.lblNewVerWidth.AutoSize = true;
            this.lblNewVerWidth.Location = new System.Drawing.Point(20, 33);
            this.lblNewVerWidth.Name = "lblNewVerWidth";
            this.lblNewVerWidth.Size = new System.Drawing.Size(56, 17);
            this.lblNewVerWidth.TabIndex = 0;
            this.lblNewVerWidth.Text = "Ancho: ";
            // 
            // gbNewHorizontal
            // 
            this.gbNewHorizontal.Controls.Add(this.nmNewHorHeigth);
            this.gbNewHorizontal.Controls.Add(this.nmNewHorWidth);
            this.gbNewHorizontal.Controls.Add(this.lblNewHorHeigth);
            this.gbNewHorizontal.Controls.Add(this.lblNewHorWidth);
            this.gbNewHorizontal.Location = new System.Drawing.Point(25, 31);
            this.gbNewHorizontal.Name = "gbNewHorizontal";
            this.gbNewHorizontal.Size = new System.Drawing.Size(192, 100);
            this.gbNewHorizontal.TabIndex = 0;
            this.gbNewHorizontal.TabStop = false;
            this.gbNewHorizontal.Text = "Horizontal";
            // 
            // nmNewHorHeigth
            // 
            this.nmNewHorHeigth.Location = new System.Drawing.Point(81, 49);
            this.nmNewHorHeigth.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmNewHorHeigth.Name = "nmNewHorHeigth";
            this.nmNewHorHeigth.Size = new System.Drawing.Size(94, 22);
            this.nmNewHorHeigth.TabIndex = 3;
            // 
            // nmNewHorWidth
            // 
            this.nmNewHorWidth.Location = new System.Drawing.Point(80, 21);
            this.nmNewHorWidth.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmNewHorWidth.Name = "nmNewHorWidth";
            this.nmNewHorWidth.Size = new System.Drawing.Size(94, 22);
            this.nmNewHorWidth.TabIndex = 2;
            // 
            // lblNewHorHeigth
            // 
            this.lblNewHorHeigth.AutoSize = true;
            this.lblNewHorHeigth.Location = new System.Drawing.Point(33, 50);
            this.lblNewHorHeigth.Name = "lblNewHorHeigth";
            this.lblNewHorHeigth.Size = new System.Drawing.Size(40, 17);
            this.lblNewHorHeigth.TabIndex = 1;
            this.lblNewHorHeigth.Text = "Alto: ";
            this.lblNewHorHeigth.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblNewHorWidth
            // 
            this.lblNewHorWidth.AutoSize = true;
            this.lblNewHorWidth.Location = new System.Drawing.Point(17, 21);
            this.lblNewHorWidth.Name = "lblNewHorWidth";
            this.lblNewHorWidth.Size = new System.Drawing.Size(56, 17);
            this.lblNewHorWidth.TabIndex = 0;
            this.lblNewHorWidth.Text = "Ancho: ";
            // 
            // gBMarcaAgua
            // 
            this.gBMarcaAgua.Controls.Add(this.txtBPropMarcaAgua);
            this.gBMarcaAgua.Controls.Add(this.lblTextoMarcaAgua);
            this.gBMarcaAgua.Location = new System.Drawing.Point(13, 303);
            this.gBMarcaAgua.Name = "gBMarcaAgua";
            this.gBMarcaAgua.Size = new System.Drawing.Size(467, 86);
            this.gBMarcaAgua.TabIndex = 3;
            this.gBMarcaAgua.TabStop = false;
            this.gBMarcaAgua.Text = "Marca de Agua: ";
            // 
            // txtBPropMarcaAgua
            // 
            this.txtBPropMarcaAgua.Location = new System.Drawing.Point(167, 35);
            this.txtBPropMarcaAgua.Name = "txtBPropMarcaAgua";
            this.txtBPropMarcaAgua.Size = new System.Drawing.Size(281, 22);
            this.txtBPropMarcaAgua.TabIndex = 1;
            // 
            // lblTextoMarcaAgua
            // 
            this.lblTextoMarcaAgua.AutoSize = true;
            this.lblTextoMarcaAgua.Location = new System.Drawing.Point(18, 35);
            this.lblTextoMarcaAgua.Name = "lblTextoMarcaAgua";
            this.lblTextoMarcaAgua.Size = new System.Drawing.Size(151, 17);
            this.lblTextoMarcaAgua.TabIndex = 0;
            this.lblTextoMarcaAgua.Text = "Texto Marca de Agua: ";
            // 
            // gBImgTmbDim
            // 
            this.gBImgTmbDim.Controls.Add(this.gBTmbVertical);
            this.gBImgTmbDim.Controls.Add(this.gBTmbHorizontal);
            this.gBImgTmbDim.Location = new System.Drawing.Point(545, 13);
            this.gBImgTmbDim.Name = "gBImgTmbDim";
            this.gBImgTmbDim.Size = new System.Drawing.Size(239, 269);
            this.gBImgTmbDim.TabIndex = 4;
            this.gBImgTmbDim.TabStop = false;
            this.gBImgTmbDim.Text = "Thumb";
            // 
            // gBTmbVertical
            // 
            this.gBTmbVertical.Controls.Add(this.nmTmbVerHeigth);
            this.gBTmbVertical.Controls.Add(this.nmTmbVerWidth);
            this.gBTmbVertical.Controls.Add(this.lblTmbVerWidth);
            this.gBTmbVertical.Controls.Add(this.lblTmbVerHeigth);
            this.gBTmbVertical.Location = new System.Drawing.Point(15, 147);
            this.gBTmbVertical.Name = "gBTmbVertical";
            this.gBTmbVertical.Size = new System.Drawing.Size(200, 100);
            this.gBTmbVertical.TabIndex = 1;
            this.gBTmbVertical.TabStop = false;
            this.gBTmbVertical.Text = "Vertical";
            // 
            // nmTmbVerHeigth
            // 
            this.nmTmbVerHeigth.Location = new System.Drawing.Point(81, 66);
            this.nmTmbVerHeigth.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmTmbVerHeigth.Name = "nmTmbVerHeigth";
            this.nmTmbVerHeigth.Size = new System.Drawing.Size(94, 22);
            this.nmTmbVerHeigth.TabIndex = 4;
            // 
            // nmTmbVerWidth
            // 
            this.nmTmbVerWidth.Location = new System.Drawing.Point(81, 32);
            this.nmTmbVerWidth.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmTmbVerWidth.Name = "nmTmbVerWidth";
            this.nmTmbVerWidth.Size = new System.Drawing.Size(94, 22);
            this.nmTmbVerWidth.TabIndex = 3;
            // 
            // lblTmbVerWidth
            // 
            this.lblTmbVerWidth.AutoSize = true;
            this.lblTmbVerWidth.Location = new System.Drawing.Point(20, 32);
            this.lblTmbVerWidth.Name = "lblTmbVerWidth";
            this.lblTmbVerWidth.Size = new System.Drawing.Size(56, 17);
            this.lblTmbVerWidth.TabIndex = 2;
            this.lblTmbVerWidth.Text = "Ancho: ";
            // 
            // lblTmbVerHeigth
            // 
            this.lblTmbVerHeigth.AutoSize = true;
            this.lblTmbVerHeigth.Location = new System.Drawing.Point(28, 66);
            this.lblTmbVerHeigth.Name = "lblTmbVerHeigth";
            this.lblTmbVerHeigth.Size = new System.Drawing.Size(40, 17);
            this.lblTmbVerHeigth.TabIndex = 0;
            this.lblTmbVerHeigth.Text = "Alto: ";
            // 
            // gBTmbHorizontal
            // 
            this.gBTmbHorizontal.Controls.Add(this.nmTmbHorHeigth);
            this.gBTmbHorizontal.Controls.Add(this.nmTmbHorWidth);
            this.gBTmbHorizontal.Controls.Add(this.lblTmbHorHeigth);
            this.gBTmbHorizontal.Controls.Add(this.lblTmbHorWidth);
            this.gBTmbHorizontal.Location = new System.Drawing.Point(15, 31);
            this.gBTmbHorizontal.Name = "gBTmbHorizontal";
            this.gBTmbHorizontal.Size = new System.Drawing.Size(200, 100);
            this.gBTmbHorizontal.TabIndex = 0;
            this.gBTmbHorizontal.TabStop = false;
            this.gBTmbHorizontal.Text = "Horizontal";
            // 
            // nmTmbHorHeigth
            // 
            this.nmTmbHorHeigth.Location = new System.Drawing.Point(81, 50);
            this.nmTmbHorHeigth.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmTmbHorHeigth.Name = "nmTmbHorHeigth";
            this.nmTmbHorHeigth.Size = new System.Drawing.Size(94, 22);
            this.nmTmbHorHeigth.TabIndex = 3;
            // 
            // nmTmbHorWidth
            // 
            this.nmTmbHorWidth.Location = new System.Drawing.Point(81, 20);
            this.nmTmbHorWidth.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmTmbHorWidth.Name = "nmTmbHorWidth";
            this.nmTmbHorWidth.Size = new System.Drawing.Size(94, 22);
            this.nmTmbHorWidth.TabIndex = 2;
            // 
            // lblTmbHorHeigth
            // 
            this.lblTmbHorHeigth.AutoSize = true;
            this.lblTmbHorHeigth.Location = new System.Drawing.Point(28, 49);
            this.lblTmbHorHeigth.Name = "lblTmbHorHeigth";
            this.lblTmbHorHeigth.Size = new System.Drawing.Size(40, 17);
            this.lblTmbHorHeigth.TabIndex = 1;
            this.lblTmbHorHeigth.Text = "Alto: ";
            // 
            // lblTmbHorWidth
            // 
            this.lblTmbHorWidth.AutoSize = true;
            this.lblTmbHorWidth.Location = new System.Drawing.Point(18, 21);
            this.lblTmbHorWidth.Name = "lblTmbHorWidth";
            this.lblTmbHorWidth.Size = new System.Drawing.Size(56, 17);
            this.lblTmbHorWidth.TabIndex = 0;
            this.lblTmbHorWidth.Text = "Ancho: ";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(449, 420);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(133, 46);
            this.btnCancelar.TabIndex = 5;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // Prop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 494);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.gBImgTmbDim);
            this.Controls.Add(this.gBMarcaAgua);
            this.Controls.Add(this.gbImgNewDim);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.gBImgShowed);
            this.Name = "Prop";
            this.Text = "Prop";
            this.gBImgShowed.ResumeLayout(false);
            this.ImgShVertical.ResumeLayout(false);
            this.ImgShVertical.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmShVerHeigth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmShVerWidth)).EndInit();
            this.ImgShHorizontal.ResumeLayout(false);
            this.ImgShHorizontal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmShHorWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmShHorHeigth)).EndInit();
            this.gbImgNewDim.ResumeLayout(false);
            this.gBNewVertical.ResumeLayout(false);
            this.gBNewVertical.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmNewVerHeigth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmNewVerWidth)).EndInit();
            this.gbNewHorizontal.ResumeLayout(false);
            this.gbNewHorizontal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmNewHorHeigth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmNewHorWidth)).EndInit();
            this.gBMarcaAgua.ResumeLayout(false);
            this.gBMarcaAgua.PerformLayout();
            this.gBImgTmbDim.ResumeLayout(false);
            this.gBTmbVertical.ResumeLayout(false);
            this.gBTmbVertical.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmTmbVerHeigth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmTmbVerWidth)).EndInit();
            this.gBTmbHorizontal.ResumeLayout(false);
            this.gBTmbHorizontal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmTmbHorHeigth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmTmbHorWidth)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gBImgShowed;
        private System.Windows.Forms.NumericUpDown nmShHorWidth;
        private System.Windows.Forms.Label lblShHeight;
        private System.Windows.Forms.Label lblShHorWidth;
        private System.Windows.Forms.NumericUpDown nmShHorHeigth;
        private System.Windows.Forms.GroupBox ImgShVertical;
        private System.Windows.Forms.NumericUpDown nmShVerHeigth;
        private System.Windows.Forms.Label lblShVerHeigth;
        private System.Windows.Forms.NumericUpDown nmShVerWidth;
        private System.Windows.Forms.Label lblShVerWidth;
        private System.Windows.Forms.GroupBox ImgShHorizontal;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.GroupBox gbImgNewDim;
        private System.Windows.Forms.GroupBox gBMarcaAgua;
        private System.Windows.Forms.TextBox txtBPropMarcaAgua;
        private System.Windows.Forms.Label lblTextoMarcaAgua;
        private System.Windows.Forms.GroupBox gbNewHorizontal;
        private System.Windows.Forms.Label lblNewHorHeigth;
        private System.Windows.Forms.Label lblNewHorWidth;
        private System.Windows.Forms.NumericUpDown nmNewHorWidth;
        private System.Windows.Forms.NumericUpDown nmNewHorHeigth;
        private System.Windows.Forms.GroupBox gBNewVertical;
        private System.Windows.Forms.NumericUpDown nmNewVerHeigth;
        private System.Windows.Forms.NumericUpDown nmNewVerWidth;
        private System.Windows.Forms.Label lblNewVerHeigth;
        private System.Windows.Forms.Label lblNewVerWidth;
        private System.Windows.Forms.GroupBox gBImgTmbDim;
        private System.Windows.Forms.GroupBox gBTmbVertical;
        private System.Windows.Forms.NumericUpDown nmTmbVerHeigth;
        private System.Windows.Forms.NumericUpDown nmTmbVerWidth;
        private System.Windows.Forms.Label lblTmbVerWidth;
        private System.Windows.Forms.Label lblTmbVerHeigth;
        private System.Windows.Forms.GroupBox gBTmbHorizontal;
        private System.Windows.Forms.NumericUpDown nmTmbHorHeigth;
        private System.Windows.Forms.NumericUpDown nmTmbHorWidth;
        private System.Windows.Forms.Label lblTmbHorHeigth;
        private System.Windows.Forms.Label lblTmbHorWidth;
        private System.Windows.Forms.Button btnCancelar;
    }
}